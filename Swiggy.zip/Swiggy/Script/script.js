
document.addEventListener("DOMContentLoaded", function() {
    // Get references to the buttons and item count display
    var decreaseBtn = document.querySelectorAll("#decreaseBtn");
    var increaseBtn = document.querySelectorAll("#increaseBtn");
    var itemCountDisplay = document.querySelectorAll("#itemCount");

    // Set initial item count
    var itemCount = [1,1,1,1];
    itemCountDisplay.textContent = itemCount[0];

    for(let i=0;i<itemCountDisplay.length;i++){
        decreaseBtn[i].addEventListener("click", function() {
            if (itemCount[i] > 1) {
                itemCount[i]--;
                itemCountDisplay[i].innerText = itemCount[i];
            }
        });
    
        // Add event listener for the increase button
        increaseBtn[i].addEventListener("click", function() {
            itemCount[i]++;
            itemCountDisplay[i].innerText = itemCount[i];
        });
    }
    // Add event listener for the decrease button
    

    // Run showFoodList() function when the DOM content is loaded
    showFoodList();
});

function showFoodList() {
    console.log("showFoodList called");
    var toggleSwitch = document.getElementById("toggleSwitch");
    var vegItems = document.querySelectorAll(".veg-item");
    var nonVegItems = document.querySelectorAll(".non-veg-item");

    if (toggleSwitch.checked) 
    {
        console.log("Veg selected");
        // Show veg items and hide non-veg items
        vegItems.forEach(item => item.style.display = "block");
        nonVegItems.forEach(item => item.style.display = "none");
    } 
    else 
    {
        console.log("Non-Veg selected");
        // Show non-veg items and hide veg items
        nonVegItems.forEach(item => item.style.display = "block");
        vegItems.forEach(item => item.style.display = "none");
    }
}

